const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
app.use(bodyParser.json());
app.use(cors());

// this is the equivalent of a persistent connection in PHP
const mysql = require('mysql');
const pool = mysql.createPool({
  host: "mysql",
  user: "webprog",
  password: "webprog",
  database: "webprog",
  connectionLimit: 10
});

var server = app.listen(8080, "nodejs",  () => {
  let host = server.address().address
  let port = server.address().port
  console.log("Contact Tracing Api listening at http://%s:%s", host, port)
})

//-------------------------------
// Returns a list of all Persons.

app.get('/persons', (req, res) => {

  pool.query("SELECT * FROM Person ORDER BY LastName", (err, result, fields) => {
    if (err) throw "Could not run query: " + err;

    res.setHeader("Content-Type", "application/json");
    console.log("Select query run: " + JSON.stringify(result));
    res.send(JSON.stringify(result));
  });
}); 

// --------------------------------
// Returns data on a single person, 
// identified by National Number.

app.get('/person/:national_number', (req, res) => {
  pool.query("SELECT * FROM Person where NationalNumber=?",  [req.params.national_number],
    (err, result, fields) => {
    if (err) throw "Could not run query: " + err;
    res.setHeader("Content-Type", "application/json");
    console.log("Select query run: " + JSON.stringify(result));
    res.send(JSON.stringify(result));
  });
});

// --------------------------------------
// Returns the contact for the person,
// identified by National Number.

app.get('/contact/:national_number', (req, res) => {
  pool.query("SELECT Person, Contact, p.FirstName, p.LastName, ContactDate, Description FROM PersonContact JOIN Person p ON p.NationalNumber = Contact WHERE Person=?",  [req.params.national_number],
    (err, result, fields) => {
    if (err) throw "Could not run query: " + err;
    res.setHeader("Content-Type", "application/json");
    console.log("Select query run: " + JSON.stringify(result));
    res.send(JSON.stringify(result));
  });
});

// -----------------------------
// Create a new contact

app.post('/contact',  (req, res) => {
    let newcontact = JSON.parse(JSON.stringify(req.body));
    pool.query("INSERT INTO PersonContact (Person, Contact, ContactDate, Description) VALUES (?, ?, ?, ?)", [newcontact.person, newcontact.contact, newcontact.contactDate, newcontact.description],
        (err, result, fields) => {
            if (err) {
                res.sendStatus(500);
            } else {
                res.setHeader("Content-Type", "application/json");
                console.log("Select query run: " + JSON.stringify(result));
                res.send(JSON.stringify(result));
            }
        });
});

// -------------------------------
// Update an existing contact

app.put('/contact',  (req, res) => {
    let contact = JSON.parse(JSON.stringify(req.body));
    pool.query("UPDATE PersonContact SET Contact= ?, ContactDate=?, Description=? WHERE Person = ?", [contact.contact, contact.contactDate, contact.description, contact.person],
        (err, result, fields) => {
            if (err) throw "Could not run query: " + err;
            res.setHeader("Content-Type", "application/json");
            console.log("Select query run: " + JSON.stringify(result));
            res.send(JSON.stringify(result));
        });
});

// ---------------------------------
// Create a new person.

app.post('/person',  (req, res) => {
  let newperson = JSON.parse(JSON.stringify(req.body));
  pool.query("INSERT INTO Person (NationalNumber, FirstName, LastName, Email, Phone, Address, Positive) VALUES (?, ?, ?, ?, ?, ?, ?)",
    [newperson.nationalNumber, newperson.firstName, newperson.lastName, newperson.email, newperson.phone, newperson.address, newperson.positive],
    (err, result, fields) => {
      if (err) throw "Could not run query: " + err;
      res.setHeader("Content-Type", "application/json");
      console.log("Select query run: " + JSON.stringify(result));
      res.send(JSON.stringify(result));
    });
});

// ----------------------------------
// Update an existing person.

app.put('/person',  (req, res) => {
  let person = JSON.parse(JSON.stringify(req.body));
  pool.query("UPDATE Person SET FirstName=?, LastName=?, Email=?, Phone=?, Address=?, Positive=? WHERE NationalNumber = ?",
      [person.firstName, person.lastName, person.email, person.phone, person.address, person.positive, person.nationalNumber],
      (err, result, fields) => {
        if (err) throw "Could not run query: " + err;
        res.setHeader("Content-Type", "application/json");
        console.log("Select query run: " + JSON.stringify(result));
        res.send(JSON.stringify(result));
      });
});

// ----------------------------------------------------------
// Delete a person, identified by National Number.
// The delete will be cascaded to the contact (if it exists).

app.delete('/person/:national_number',  (req, res) => {
  pool.query("DELETE FROM Person WHERE NationalNumber = ?", [req.params.national_number],
      (err, result, fields) => {
        if (err) throw "Could not run query: " + err;
        res.setHeader("Content-Type", "application/json");
        console.log("Select query run: " + JSON.stringify(result));
        res.send(JSON.stringify(result));
      });
});